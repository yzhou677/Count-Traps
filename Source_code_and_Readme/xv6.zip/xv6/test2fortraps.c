#include "types.h"
#include "stat.h"
#include "user.h"

void
forktest(void)
{
  int pid;
  pid = fork();
  if(pid > 0){
    printf(1,"");
    pid = wait();
    printf(1,"");
 }else if(pid == 0){
    printf(1,"");
    exit();
  } else {
    printf(1,"error");
  }
}

int
main(void)
{
 forktest();
 countTraps();
 exit();
}
