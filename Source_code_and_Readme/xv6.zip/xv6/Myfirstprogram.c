#include "types.h"
#include "stat.h"
#include "user.h"

int main(void) 
{
printf(1,"Yuqi's first C program on xv6\n");
printf(1,"Hello world, my name is Yuqi Zhou and CWID is A20423555\n");
exit();
}
