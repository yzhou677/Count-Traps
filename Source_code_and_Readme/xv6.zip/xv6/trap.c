#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"
#include "traps.h"
#include "spinlock.h"

// Interrupt descriptor table (shared by all CPUs).
struct gatedesc idt[256];
extern uint vectors[];  // in vectors.S: array of 256 entry pointers
struct spinlock tickslock;
uint ticks;
//extern int countSyscall[22];
//extern int countOtherTraps[19];

void
countothertraps(struct trapframe *tf)
{
  
   if(tf->trapno == T_DIVIDE){
     myproc()->countOtherTraps[0] = myproc()->countOtherTraps[0] + 1;
   }
   if(tf->trapno == T_DEBUG){
     myproc()->countOtherTraps[1] = myproc()->countOtherTraps[1] + 1;
   }
  if(tf->trapno == T_NMI){
    myproc()->countOtherTraps[2] = myproc()->countOtherTraps[2] + 1;
   }
  if(tf->trapno == T_BRKPT){
     myproc()->countOtherTraps[3] = myproc()->countOtherTraps[3] + 1;
   }
  if(tf->trapno == T_OFLOW){
     myproc()->countOtherTraps[4] = myproc()->countOtherTraps[4] + 1;
   }
  if(tf->trapno == T_BOUND){
     myproc()->countOtherTraps[5] = myproc()->countOtherTraps[5] + 1;
   }
  if(tf->trapno == T_ILLOP){
     myproc()->countOtherTraps[6] = myproc()->countOtherTraps[6] + 1;
   }
  if(tf->trapno == T_DEVICE){
     myproc()->countOtherTraps[7] = myproc()->countOtherTraps[7] + 1;
   }
  if(tf->trapno == T_DBLFLT){
     myproc()->countOtherTraps[8] = myproc()->countOtherTraps[8] + 1;
   }
  if(tf->trapno == T_TSS){
     myproc()->countOtherTraps[9] = myproc()->countOtherTraps[9] + 1;
   }
  if(tf->trapno == T_SEGNP){
     myproc()->countOtherTraps[10] = myproc()->countOtherTraps[10] + 1;
   }
  if(tf->trapno == T_STACK){
     myproc()->countOtherTraps[11] = myproc()->countOtherTraps[11] + 1;
   }
  if(tf->trapno == T_GPFLT){
     myproc()->countOtherTraps[12] = myproc()->countOtherTraps[12] + 1;
   }
  if(tf->trapno == T_PGFLT){
     myproc()->countOtherTraps[13] = myproc()->countOtherTraps[13] + 1;
   }
  if(tf->trapno == T_FPERR){
     myproc()->countOtherTraps[14] = myproc()->countOtherTraps[14] + 1;
   }
  if(tf->trapno == T_ALIGN){
     myproc()->countOtherTraps[15] = myproc()->countOtherTraps[15] + 1;
   }
  if(tf->trapno == T_MCHK){
     myproc()->countOtherTraps[16] = myproc()->countOtherTraps[16] + 1;
   }
  if(tf->trapno == T_SIMDERR){
     myproc()->countOtherTraps[17] = myproc()->countOtherTraps[17] + 1;
   }
  if(tf->trapno == T_DEFAULT){
     myproc()->countOtherTraps[18] = myproc()->countOtherTraps[18] + 1;
   }
  
}

void
tvinit(void)
{
  int i;

  for(i = 0; i < 256; i++)
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);

  initlock(&tickslock, "time");
}

void
idtinit(void)
{
  lidt(idt, sizeof(idt));
}

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
  if(tf->trapno == T_SYSCALL){
    if(myproc()->killed)
      exit();
    int num;
    int i;
    num = tf->eax;
    i = num - 1;
    myproc()->tf = tf;
    myproc()->countSyscall[i] = myproc()->countSyscall[i] + 1;
    syscall();
    if(myproc()->killed)
      exit();
    return;
  }
  countothertraps(tf);
  
  switch(tf->trapno){
  case T_IRQ0 + IRQ_TIMER:
    if(cpuid() == 0){
      acquire(&tickslock);
      ticks++;
      wakeup(&ticks);
      release(&tickslock);
    }
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE:
    ideintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE+1:
    // Bochs generates spurious IDE1 interrupts.
    break;
  case T_IRQ0 + IRQ_KBD:
    kbdintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_COM1:
    uartintr();
    lapiceoi();
    break;
  case T_IRQ0 + 7:
  case T_IRQ0 + IRQ_SPURIOUS:
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
            cpuid(), tf->cs, tf->eip);
    lapiceoi();
    break;

  //PAGEBREAK: 13
  default:
    if(myproc() == 0 || (tf->cs&3) == 0){
      // In kernel, it must be our mistake.
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
              tf->trapno, cpuid(), tf->eip, rcr2());
      panic("trap");
    }
    // In user space, assume process misbehaved.
    cprintf("pid %d %s: trap %d err %d on cpu %d "
            "eip 0x%x addr 0x%x--kill proc\n",
            myproc()->pid, myproc()->name, tf->trapno,
            tf->err, cpuid(), tf->eip, rcr2());
    myproc()->killed = 1;
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
    exit();

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(myproc() && myproc()->state == RUNNING &&
     tf->trapno == T_IRQ0+IRQ_TIMER)
    yield();

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
    exit();
}
